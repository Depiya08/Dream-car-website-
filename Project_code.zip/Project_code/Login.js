const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});
// Show password functionality
const showPasswordSignup = document.getElementById('show-password-signup');
const signupPassword = document.getElementById('signup-password');

showPasswordSignup.addEventListener('change', () => {
    if (showPasswordSignup.checked) {
        signupPassword.type = 'text';
    } else {
        signupPassword.type = 'password';
    }
});

const showPasswordSignin = document.getElementById('show-password-signin');
const signinPassword = document.getElementById('signin-password');

showPasswordSignin.addEventListener('change', () => {
    if (showPasswordSignin.checked) {
        signinPassword.type = 'text';
    } else {
        signinPassword.type = 'password';
    }
});

// Login button validation
const loginForm = document.getElementById('login-form');
const loginButton = document.getElementById('login-button');
const emailInput = document.getElementById('signin-email');
const passwordInput = document.getElementById('signin-password');

loginForm.addEventListener('input', () => {
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (email !== '' && password !== '') {
        loginButton.removeAttribute('disabled');
    } else {
        loginButton.setAttribute('disabled', 'disabled');
    }
});

// Redirect to customer page
loginForm.addEventListener('submit', (e) => {
    e.preventDefault(); // Prevent default form submission
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    if (email !== '' && password !== '') {
        // Redirect to the customer page
        window.location.href = "Customer_Page.html";
    }
});